Lab 4 - README
==========================================================

LEADER
mrubi005@ucr.edu

MEMBERS
==========================================================
mrubi005@ucr.edu

REMARKS
- This lab should run unlike last quarters
- I set this lab up for lab 5 that is coming up so all the variable names should be easier to understand and i created clearer sections, at least for me.
- I did have trouble getting it to work because my ALU_CONTROL was missing the NOR operation.
- I added the NOR operation so it functioned properly
- I also used parameters the right way for the muxes. meaning that instead of using "defparam" i used #(parameter) in the instantiation of the module. 
- I added a screenshot of my results.
==========================================================

BUGS IF ANY 
- No known bugs



==========================================================

ORIGINAL WORK STATEMENT
- I certify that this submission represents my own original work. This submission was not done in collaboration nor was any substanial portion of the code obtained from third parties, including websites and the like.
