Lab 5 - README
==========================================================

LEADER
mrubi005@ucr.edu

MEMBERS
==========================================================
mrubi005@ucr.edu

REMARKS
- This CAM should be better organized then last quarters. It was straight forward to implement the cams.
- I had used TCAM in my first implementation but I realized it made more since to use STCAM.

==========================================================

BUGS IF ANY 
- Im hoping I have no errors in my code could not find any.


==========================================================

ORIGINAL WORK STATEMENT
- I certify that this submission represents my own original work. This submission was not done in collaboration nor was any substanial portion of the code obtained from third parties, including websites and the like.
