Lab 8 - README
==========================================================

LEADER
mrubi005@ucr.edu

MEMBERS
==========================================================
mrubi005@ucr.edu

REMARKS
- The Binary to BCD converter and the BCD to Binary converters seem to work for unsigned numbers.
- the main testbench to look for is alu_master_tb
- BinarytoBCD_tb test the Binary to BCD conversion
- BCDtoBinary_tb test the BCD to Binary conversion

==========================================================

BUGS IF ANY 
- Code does not work well with signed numbers. Bug might be in Binary to BCD converter.
- The alu does not seem to properly handle signed numbers
- Not sure if correct use of overflow and carry out was used. the website http://teaching.idallen.com/dat2343/10f/notes/040_overflow.txt was used to aid


==========================================================

ORIGINAL WORK STATEMENT
- I certify that this submission represents my own original work. This submission was not done in collaboration nor was any substanial portion of the code obtained from third parties, including websites and the like.
